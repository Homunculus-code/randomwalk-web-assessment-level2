/* here we assign the html ui/ux components to their own containers */
const cells = document.querySelectorAll('[data-cell]');
const restartButton = document.getElementById('restartButton');
const statusElement = document.getElementById('status');
const scoreX = document.getElementById('scoreX');
const scoreO = document.getElementById('scoreO');
const playerXName = document.getElementById('playerXName');
const playerOName = document.getElementById('playerOName');
const inputPlayerX = document.getElementById('inputPlayerX');
const inputPlayerO = document.getElementById('inputPlayerO');
const changeNamesButton = document.getElementById('changeNamesButton');
const board = document.getElementById('.board');
const markSound = document.getElementById('markSound');
const winSound = document.getElementById('winSound');
const historyList = document.getElementById('historyList');
const playerXup = document.getElementById('playerXUp');
const playerOup = document.getElementById('playerOUp');

let currentPlayer = 'X'; //represents the current player, set to X as X starts first
let boardState = ['', '', '', '', '', '', '', '', '']; //represents the value of each cell
let scoreXValue = 0; //represents the score of player X
let scoreOValue = 0; //represents the score of player O

//an array that contains the position of the winning combinations
const winningCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6]
];

//event listeners are added to each cell to check for mouse click
cells.forEach(cell => {
    cell.addEventListener('click', handleClick);
});

//upon clicking, the following function is called
function handleClick(e) {
    const cell = e.target;
    const index = Array.from(cells).indexOf(cell);

    //prevents placing a mark in an already-filled cell
    if (boardState[index]) {
        alert('Cell is already filled! Please choose another cell.');
        return;
    }

    //plays a sound to indicate that a mark has been placed
    markSound.play();
    placeMark(cell, index);

    //timeout is set so that the mark is visually placed before the result is announced
    setTimeout(() => {
        if (checkWin()) {
            winSound.play();
            alert(`${currentPlayer} wins!`);
            updateScore();
            resetBoard();
            return;
        }

        //check for a draw
        if (boardState.every(cell => cell)) {
            alert("It's a draw!");
            const timestamp = new Date().toLocaleString(); //creates list object content to add DRAW event to game history
            const historyItem = document.createElement('li'); 
            historyItem.style.backgroundColor = 'gray';
            historyItem.textContent = `DRAW, ${scoreXValue} - ${scoreOValue}, ${timestamp}`; //creates list object content
            historyList.prepend(historyItem);
            resetBoard();
            return;
        }

        //swaps the player to the next one
        swapPlayer();
    }, 100);
}

function placeMark(cell, index) {
    boardState[index] = currentPlayer; //places the mark of the current player in board state array
    cell.textContent = currentPlayer; //changes content of that cell to mark of current player
    //pink represents X, blue represents O
    if (currentPlayer === 'X') {
        cell.style.backgroundColor = '#ffcccc';//changes cell color to pink
    } else {
        cell.style.backgroundColor = '#cce7ff';//changes cell color to blue
    }
    cell.classList.add('taken');//adds taken to indicate that it is occupied
}

//used to change to next player and alter the visual indicator of whose turn it is
function swapPlayer() {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X'; //changes to the next player
    statusElement.textContent = `${currentPlayer}'s TURN`; //alters text to display whose turn it is
    //alters color of the status bar
    if (currentPlayer === 'X') 
    {
        statusElement.style.backgroundColor = '#ffcccc';
        document.querySelector('.board').style.backgroundColor = 'rgba(255, 204, 204, 0.5)';
    }
    else 
    {
        statusElement.style.backgroundColor = '#cce7ff';
        document.querySelector('.board').style.backgroundColor = 'rgba(204, 231, 255, 0.5)';
    }
}

//checks if any combination in the board matches that in the array of winning conditions
function checkWin() {
    return winningCombinations.some(combination => {
        return combination.every(index => {
            return boardState[index] === currentPlayer;
        });
    });
}

//in case of victory, increments the score of the respective player and updates game history
function updateScore() {
    const historyItem = document.createElement('li'); //creates a list item element to add to game history
    //color-codes game history list items (pink and blue for X and O) and increments counts
    if (currentPlayer === 'X') {
        scoreXValue++; 
        historyItem.style.backgroundColor = 'rgba(255, 204, 204, 0.5)';  
    } else {
        scoreOValue++;
        historyItem.style.backgroundColor = 'rgba(204, 231, 255, 0.5)';
    }

    //alters scoreboard
    scoreX.textContent = `${scoreXValue}`; 
    scoreO.textContent = `${scoreOValue}`;

    //this indicates which player is winning or losing by using a green upwards arrow or using gray arrows for draws
    if (scoreXValue > scoreOValue)
    {
        playerXup.style.display = 'inline'; //displays green arrow of winning player
        playerXup.style.color = 'green';
        playerOup.style.display = 'none'; //hides green arrow of losing player
    }
    else if (scoreOValue > scoreXValue)
    {
        playerOup.style.display = 'inline';
        playerOup.style.color = 'green';
        playerXup.style.display = 'none';
    }
    else
    {
        playerXup.style.color = 'gray'; 
        playerOup.style.color = 'gray';
        playerXup.style.display = 'inline';
        playerOup.style.display = 'inline'; 
    }

    const timestamp = new Date().toLocaleString(); //gets current time
    historyItem.textContent = `${currentPlayer} won, ${scoreXValue} - ${scoreOValue}, ${timestamp}`; //creates list object content
    historyList.prepend(historyItem); //adds list object to list
}

//upon match completion, this function is called to reset the board and game variables
function resetBoard() {
    boardState = ['', '', '', '', '', '', '', '', ''];
    cells.forEach(cell => {
        cell.textContent = '';
        cell.classList.remove('taken');
        cell.style.backgroundColor = 'white';
    });
    currentPlayer = 'X';
    statusElement.textContent = "X's TURN";
}

//a restart button to reset scores and start the game from the beginning
restartButton.addEventListener('click', () => {
    scoreXValue = 0;
    scoreOValue = 0;
    scoreX.textContent = '0';
    scoreO.textContent = '0';
    const historyItem = document.createElement('li'); 
    historyItem.textContent = `SCORES RESET`; //creates list object content to create RESET event in game history
    historyList.prepend(historyItem);
    playerXup.style.display = 'none'; //removes markers
    playerOup.style.display = 'none'; 
    resetBoard();
});

//a function to change the default player names 'player x' and 'player y'
changeNamesButton.addEventListener('click', () => {
    if (inputPlayerX.style.display === 'none') {
        inputPlayerX.style.display = 'inline'; //toggles invisible input field 
        inputPlayerO.style.display = 'inline';
        playerOName.style.display = 'none'; //hides player name while it is being altered
        playerXName.style.display = 'none';
    } else {
        playerXName.textContent = inputPlayerX.value || 'PLAYER O';  //default name if no input
        playerOName.textContent = inputPlayerO.value || 'PLAYER X';  //default name if no input
        inputPlayerX.style.display = 'none'; //input field is made invisible
        inputPlayerO.style.display = 'none';
        playerXName.style.display = 'inline'; //player names are made visible
        playerOName.style.display = 'inline';
    }
});
